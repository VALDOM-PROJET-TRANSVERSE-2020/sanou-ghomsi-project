# coding: utf-8

import sys
from setuptools import setup, find_packages

NAME = "swagger_server"
VERSION = "1.0.0"
# To install the library, run the following
#
# python setup.py install
#
# prerequisite: setuptools
# http://pypi.python.org/pypi/setuptools

REQUIRES = ["connexion"]

setup(
    name=NAME,
    version=VERSION,
    description="Pneumonia Detector",
    author_email="desire.sanoupro@gmail.com",
    url="",
    keywords=["Swagger", "Pneumonia Detector"],
    install_requires=REQUIRES,
    packages=find_packages(),
    package_data={'': ['swagger/swagger.yaml']},
    include_package_data=True,
    entry_points={
        'console_scripts': ['swagger_server=swagger_server.__main__:main']},
    long_description="""\
    This API aims to help you make a diagnosis of a human chest. It can detect if the chest has pneumonia or not. All you need to do is give it an xray-images of extensions: .jpeg, .jpg, .png . Make sure the total size of all your images do not exceed 1GB. Find out more on : https://github.com/VALDOM-PROJET-TRANSVERSE-2020/sanou-ghomsi-project
    """
)
