import connexion
import six

from swagger_server import util


def apitest_get():  # noqa: E501
    """Simple test to make sure the API is Working

     # noqa: E501


    :rtype: str
    """
    return 'do some magic!'
