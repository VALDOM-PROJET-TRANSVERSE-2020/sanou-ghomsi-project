import connexion
import six

from swagger_server import util


def predictions_get():  # noqa: E501
    """Make et return predictions on uploaded files

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
