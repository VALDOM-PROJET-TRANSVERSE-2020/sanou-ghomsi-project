import connexion
import six

from swagger_server import util


def makepredictions(files):  # noqa: E501
    """Upload your xray-image-files to make predictions

     # noqa: E501

    :param files: 
    :type files: List[strstr]

    :rtype: None
    """
    return 'do some magic!'
