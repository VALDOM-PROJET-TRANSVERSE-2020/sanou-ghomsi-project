# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestSaveFilesController(BaseTestCase):
    """SaveFilesController integration test stubs"""

    def test_makepredictions(self):
        """Test case for makepredictions

        Upload your xray-image-files to make predictions
        """
        data = dict(files='files_example')
        response = self.client.open(
            '//save_files',
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
